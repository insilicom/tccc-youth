from flask import Flask, render_template, url_for

application = Flask(__name__)

@application.route("/")
def index():
    return render_template('index.html')

@application.route("/mission")
def mission():
    return render_template('mission.html')

@application.route("/resources")
def resources():
    return render_template('resources.html')

@application.route("/activities")
def activities():
    return render_template('activities.html')

if __name__ == "__main__":
    application.run(debug=True)
